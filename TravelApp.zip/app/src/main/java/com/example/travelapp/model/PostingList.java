package com.example.travelapp.model;

import java.util.ArrayList;


public class PostingList {

    public String result;
    public ArrayList<Posting> items;

    public int count;


}
