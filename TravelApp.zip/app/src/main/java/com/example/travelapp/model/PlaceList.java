package com.example.travelapp.model;

import java.util.ArrayList;


public class PlaceList {

    public String result;
    public ArrayList<Place> items;

    public int count;


}
