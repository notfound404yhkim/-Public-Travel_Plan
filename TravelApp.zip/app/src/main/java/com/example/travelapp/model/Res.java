package com.example.travelapp.model;

import java.util.ArrayList;

public class Res {

    public String result;
    public ArrayList<String> items;

}
