package com.example.travelapp.config;

public class Config {

    public static final String PREFERENCE_NAME = "Travel_app";
    public static final String DOMAIN = "https://wmsysdajx5.execute-api.ap-northeast-2.amazonaws.com";
    public static final String DOMAIN_LOCAL = "http://localhost:5000";

}
