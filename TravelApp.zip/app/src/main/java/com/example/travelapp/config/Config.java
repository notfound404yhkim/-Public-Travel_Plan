package com.example.travelapp.config;

public class Config {

    public static final String PREFERENCE_NAME = "Travel_app";
    public static final String DOMAIN = "https://rh9bcgtmbg.execute-api.ap-northeast-2.amazonaws.com";
    public static final String DOMAIN_LOCAL = "http://localhost:5000";

}
