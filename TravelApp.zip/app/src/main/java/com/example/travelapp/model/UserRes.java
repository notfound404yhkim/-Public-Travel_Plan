package com.example.travelapp.model;

public class UserRes {
    public String result;
    public String tokken;
    public String accessToken;

}
